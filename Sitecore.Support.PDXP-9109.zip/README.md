Before applying the patch, please perform the following steps:

    1. **Remove** `App_Config\Include\zzz\Sitecore.Support.619349.config` from `ContentManagement` or `Standalone` instances (if applicable).
    2. **Remove** `bin\Sitecore.Support.619349.dll` from `ContentManagement` or `Standalone` instances (if applicable).