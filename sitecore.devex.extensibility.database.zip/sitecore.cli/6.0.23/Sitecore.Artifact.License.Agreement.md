Sitecore Corporation A/S - License Agreement
=============

1. **This Agreement.** Any use of the artifact package content provided by Sitecore ("Materials")
    shall be governed by this license ("Agreement"). This Agreement shall apply to any person or
    application for each access or any other use of the Materials with any device or in any form
    ("You" or "Your"). You may not and will immediately discontinue any use or access of
    the Materials if you do not acknowledge and fully agree with this License.

2. **Materials.** Sitecore grants you a limited, temporary, non-exclusive, non-transferable,
    non-assignable, and non-sublicensable license to access and use the Materials in compliance with
    all applicable laws and this Agreement. Ownership of the Materials and all worldwide rights,
    title and interest in and to any intellectual property associated with the Materials shall
    remain solely and exclusively with Sitecore or the respective owners of such intellectual
    property. You acknowledge and agree no intellectual property rights of any kind, whether now
    known or later developed, are transferred under this Agreement to You.

3. **Your Input.** You may transmit or publish content, suggestions, enhancement requests,
    recommendations or other feedback created by You ("User Content"). You do not transfer any
    ownership right in the User Content and you hereby grant Sitecore a non-exclusive, royalty-free,
    worldwide, transferable, sublicensable, irrevocable, perpetual license to use, copy (in whole or
    in part), modify, display in any form now known or hereinafter developed, distribute, and make
    derivative works of, including by incorporating into any product or service owned by Sitecore,
    any User Content provided by You relating to any product or service owned by Sitecore. You are
    solely responsible User Content and the consequences of its transmission or publication.

4. **Restrictions.** You agree not to (a) reverse engineer or attempt to derive the source code from
    or create derivative works of the Materials, or any portion thereof; (b) use the Materials in a
    greater capacity than authorized under this Agreement; (c) sublicense, distribute or pledge
    the Materials, (d) access, use, or copy any portion of the Materials to directly or indirectly
    to develop, promote or support any product or service that is competitive with Sitecore,
    (e) lease, rent or commercially share or otherwise use the Materials for purposes of providing
    a service bureau or providing third party hosting, application service provider type services;
    (f) remove any identification, patent, trademark, copyright, or other notice from the Materials;
    (g) attempt to gain unauthorized access to the Materials or the related systems or networks;
    (h) use any name, mark, or designation of Sitecore, or any of its affiliates or licensors or
    their respective products or services, unless expressly permitted herein or by Sitecore in
    writing; (i) use the Materials in any manner that brings any Sitecore brands, trademarks,
    products or services into disrepute or (j) where Your use of the Materials is for a customer of
    Sitecore that has entered a separate license agreement, in any manner not authorized by Sitecore
    under such license agreement.

5. **Modification of Terms.** Sitecore reserves the right to modify this Agreement at any time.
    Modifications to this Agreement are effective immediately and shall apply upon Your continued
    access or use of the Materials.

6. **DISCLAIMER OF WARRANTY.** YOU EXPRESSLY UNDERSTAND AND AGREE THAT:

    a.  YOUR USE OF THE MATERIALS IS AT YOUR SOLE RISK. THE MATERIALS PROVIDED ON AN "AS IS" AND
        "AS AVAILABLE" BASIS. SITECORE EXPRESSLY DISCLAIMS ALL WARRANTIES OF ANY KIND, WHETHER
        EXPRESS OR IMPLIED, INCLUDING, BUT NOT LIMITED TO THE IMPLIED WARRANTIES OF MERCHANTABILITY,
        FITNESS FOR A PARTICULAR PURPOSE AND NON-INFRINGEMENT.

    b.  SITECORE WILL MAKE REASONABLE EFFORTS TO MAINTAIN THE MATERIALS, HOWEVER, SITECORE IS NOT
        RESPONSIBLE FOR ANY DAMAGE, LOSS OF DATA, INFORMATION, REVENUE, OR OTHER HARM TO BUSINESS
        ARISING OUT OF DELAYS, SITE INTERRUPTION, MISDELIVERY OR NONDELIVERY OF INFORMATION,
        RESTRICTION OR LOSS OF ACCESS, BUGS OR OTHER ERRORS, UNAUTHORIZED USE DUE TO YOUR SHARING OF
        ACCESS TO THE SERVICE, OR OTHER INTERACTION WITH THE SERVICE. YOU ARE RESPONSIBLE FOR
        MAINTAINING AND BACKING-UP YOUR DATA AND INFORMATION THAT MAY RESIDE ON THE SERVICE.
        SITECORE DOES NOT WARRANT THAT:

            i.   THE MATERIALS WILL MEET YOUR SPECIFIC REQUIREMENTS;
            ii.  ACCESS TO THE MATERIALS WILL BE UNINTERRUPTED, TIMELY, SECURE, OR THAT
                 THE MATERIALS WILL BE ERROR-FREE;
            iii. THE RESULTS THAT MAY BE OBTAINED FROM THE USE OF THE MATERIALS WILL BE ACCURATE
                 OR RELIABLE;
            iv.  THE QUALITY OF ANY PRODUCTS, SERVICES, INFORMATION, OR OTHER MATERIAL PURCHASED OR
                 OBTAINED BY YOU THROUGH THE MATERIALS WILL MEET YOUR EXPECTATIONS; OR
            v.   ANY ERRORS IN THE MATERIALS WILL BE CORRECTED.

    c.  ANY MATERIAL DOWNLOADED OR OTHERWISE OBTAINED THROUGH THE USE OF THE MATERIALS IS DONE AT
        YOUR OWN DISCRETION AND RISK AND THAT YOU WILL BE SOLELY RESPONSIBLE FOR ANY DAMAGE TO YOUR
        COMPUTER SYSTEM OR LOSS OF DATA THAT RESULTS FROM THE DOWNLOAD OF ANY SUCH MATERIAL.

    d.  NO ADVICE OR INFORMATION, WHETHER ORAL OR WRITTEN, OBTAINED THROUGH OR FROM THE MATERIAL
        SHALL CREATE ANY WARRANTY NOT EXPRESSLY STATED IN THESE TERMS, INCLUDING ANY STATEMENT BY
        A SITECORE EMPLOYEE, AFFILIATE, DIRECTOR, OFFICER, OR AGENT.

    e.  THE DISCLAIMERS IN THIS SECTION OF ANY EXPRESS OR IMPLIED WARRANTY BY SITECORE SHALL INCLUDE
        WITHOUT LIMITATION SITECORE'S PARENTS, SUBSIDIARIES, AFFILIATES, DIRECTORS, EMPLOYEES,
        AND AGENTS.

7. **LIMITATION OF LIABILITY.** YOU EXPRESSLY UNDERSTAND AND AGREE THAT SITECORE SHALL NOT BE LIABLE
    FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL, CONSEQUENTIAL OR EXEMPLARY DAMAGES, INCLUDING BUT
    NOT LIMITED TO, DAMAGES FOR LOSS OF PROFITS, GOODWILL, USE, DATA OR OTHER INTANGIBLE LOSSES
    (EVEN IF SITECORE HAS BEEN ADVISED OF THE POSSIBILITY OF SUCH DAMAGES), RESULTING FROM:

        a.  THE USE OR THE INABILITY TO USE THE MATERIALS;
        b.  THE COST OF PROCUREMENT OF SUBSTITUTE GOODS AND SERVICES RESULTING
            FROM THE USE OF MATERIALS; OR
        c.  UNAUTHORIZED ACCESS TO OR ALTERATION OF YOUR TRANSMISSIONS OR DATA.

8. **EXCLUSIONS AND LIMITATIONS.** SOME JURISDICTIONS DO NOT ALLOW THE EXCLUSION OF CERTAIN
    WARRANTIES OR THE LIMITATION OR EXCLUSION OF LIABILITY FOR INCIDENTAL OR CONSEQUENTIAL DAMAGES.
    ACCORDINGLY, SOME OF THE ABOVE LIMITATIONS MAY NOT APPLY TO YOU AND SHALL ONLY APPLY TO
    THE FULLEST EXTENT PERMITTED UNDER THE APPLICABLE LAW(S).

9. **Export Control.** Sitecore's software, services, and content in the Materials may be subject to
    U.S. and international trade and export control laws. You agree to comply with all such laws.

10. **Governing Law and Process.** The English version of this Agreement shall be used when
    interpreting and applying the provisions herein. If You reside in the U.S., You irrevocably
    consent to the exclusive jurisdiction and venue of the state and federal courts located in
    San Francisco County of California in accordance with the laws of the State of California. If
    You reside outside the U.S., You irrevocably consent to the exclusive jurisdiction and venue of
    the City Court of Copenhagen, Denmark in accordance with the laws of Denmark. This paragraph
    applies without reference to conflict of laws principles and excludes the UN Convention on
    Contracts for the International Sale of Goods and the Uniform Computer Information Transaction
    Act. In any action to enforce this Agreement, the prevailing party will be entitled to costs and
    attorneys' fees.

11. **Agreement.** This Agreement constitutes the entire agreement between the parties hereto
    pertaining to the subject matter hereof, and any and all written or oral agreements heretofore
    existing between the parties hereto are expressly canceled. This Agreement is not assignable,
    transferable or sub-licensable by you except with prior written consent. Any heading, caption or
    section title contained in this Agreement is inserted only as a matter of convenience and in no
    way defines or explains any section or provision hereof. Sitecore reserves the right in its sole
    discretion to terminate the use of the Materials by a user at any time.

&#169; 2016-2022 Sitecore Corporation A/S. All rights reserved.